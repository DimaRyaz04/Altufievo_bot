﻿
using System.Collections.Generic;
using System.Linq;
using Telegram.Bot.Types.ReplyMarkups;

namespace PartsCatalogBot;

public class BotMenu
{
    public InlineKeyboardMarkup MainMenu()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "📦 Каталог запчастей", "catalog")
            }
        });
    }

    public InlineKeyboardMarkup CreateKeyboard(
        IEnumerable<(string Text, string CallbackData)> buttons)
    {
        return new InlineKeyboardMarkup(
            buttons.Select(button => new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    button.Text, button.CallbackData)
            }));
    }

    public InlineKeyboardMarkup Categories(
        IEnumerable<CatalogCategory> categories)
    {
        var rows = categories.Select(category => new[]
        {
            InlineKeyboardButton.WithCallbackData(
                category.Name, $"category:{category.Id}")
        }).ToList();

        rows.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData("🏠 Главная", "home")
        });

        return new InlineKeyboardMarkup(rows);
    }

    public InlineKeyboardMarkup Parts(
        IEnumerable<CatalogPart> parts,
        string categoryId)
    {
        var rows = parts.Select(part => new[]
        {
            InlineKeyboardButton.WithCallbackData(
                part.Name, $"part:{part.Id}")
        }).ToList();

        rows.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData(
                "⬅️ Назад", $"category:{categoryId}")
        });

        rows.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData("🏠 Главная", "home")
        });

        return new InlineKeyboardMarkup(rows);
    }
}
