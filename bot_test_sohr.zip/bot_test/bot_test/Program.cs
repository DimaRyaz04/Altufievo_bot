﻿
using Telegram.Bot;
using Telegram.Bot.Polling;
using Telegram.Bot.Types.Enums;

namespace PartsCatalogBot;

internal static class Program
{
    private static async Task Main()
    {
        Console.Write("Введи токен Telegram-бота: ");
        var token = Console.ReadLine()?.Trim();

        if (string.IsNullOrWhiteSpace(token))
        {
            Console.WriteLine("Токен не указан.");
            return;
        }

        using var cancellation = new CancellationTokenSource();

        Console.CancelKeyPress += (_, e) =>
        {
            e.Cancel = true;
            cancellation.Cancel();
        };

        try
        {
            var bot = new TelegramBotClient(token);
            var me = await bot.GetMe(
                cancellationToken: cancellation.Token);

            Console.WriteLine($"Подключено: @{me.Username}");

            var service = new BotService(
                new CatalogService(),
                new BotMenu());

            bot.StartReceiving(
                updateHandler: service.HandleUpdateAsync,
                errorHandler: service.HandleErrorAsync,
                receiverOptions: new ReceiverOptions
                {
                    AllowedUpdates = Array.Empty<UpdateType>()
                },
                cancellationToken: cancellation.Token);

            Console.WriteLine("Бот запущен. Для остановки нажми Ctrl+C.");

            await Task.Delay(
                Timeout.Infinite,
                cancellation.Token);
        }
        catch (OperationCanceledException)
        {
            Console.WriteLine("Бот остановлен.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
    }
}
