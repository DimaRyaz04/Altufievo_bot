﻿
using Telegram.Bot;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;

namespace PartsCatalogBot;

public class BotService
{
    private readonly CatalogService _catalog;
    private readonly BotMenu _menu;

    public BotService(CatalogService catalog, BotMenu menu)
    {
        _catalog = catalog;
        _menu = menu;
    }

    public async Task HandleUpdateAsync(
        ITelegramBotClient botClient,
        Update update,
        CancellationToken cancellationToken)
    {
        if (update.Type == UpdateType.Message &&
            update.Message is { Text: not null } message)
        {
            if (message.Text == "/start" || message.Text == "/menu")
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "Каталог запчастей. Выберите действие:",
                    replyMarkup: _menu.MainMenu(),
                    cancellationToken: cancellationToken);
            }

            return;
        }

        if (update.Type != UpdateType.CallbackQuery ||
            update.CallbackQuery is not { } callback)
        {
            return;
        }

        await botClient.AnswerCallbackQuery(
            callbackQueryId: callback.Id,
            cancellationToken: cancellationToken);

        if (callback.Message is not { } callbackMessage)
            return;

        var chatId = callbackMessage.Chat.Id;
        var messageId = callbackMessage.MessageId;
        var data = callback.Data ?? "";

        string text;
        InlineKeyboardMarkup keyboard;

        if (data == "home")
        {
            text = "Каталог запчастей. Выберите действие:";
            keyboard = _menu.MainMenu();
        }
        else if (data == "catalog")
        {
            var categories = _catalog.GetCategories();

            text = categories.Count == 0
                ? "Категорий пока нет."
                : "Выберите категорию:";

            keyboard = _menu.Categories(categories);
        }
        else if (data.StartsWith("category:"))
        {
            var categoryId = data["category:".Length..];
            var parts = _catalog.GetParts(categoryId);

            text = parts.Count == 0
                ? "В этой категории пока нет запчастей."
                : "Выберите запчасть:";

            keyboard = _menu.Parts(parts, categoryId);
        }

        else
        {
            text = "Действие не найдено. Вернитесь в каталог.";
            keyboard = _menu.MainMenu();
        }

        try
        {
            await botClient.EditMessageText(
                chatId: chatId,
                messageId: messageId,
                text: text,
                replyMarkup: keyboard,
                cancellationToken: cancellationToken);
        }
        catch (ApiRequestException ex) when (
            ex.Message.Contains(
                "message is not modified",
                StringComparison.OrdinalIgnoreCase))
        {
            // Сообщение уже содержит нужный текст и кнопки.
        }
    }

    public Task HandleErrorAsync(
        ITelegramBotClient botClient,
        Exception exception,
        HandleErrorSource source,
        CancellationToken cancellationToken)
    {
        Console.WriteLine($"Ошибка Telegram: {exception.Message}");
        return Task.CompletedTask;
    }
}
