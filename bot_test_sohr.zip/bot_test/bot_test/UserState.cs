﻿
namespace PartsCatalogBot;

public sealed class UserState
{
    public UserStep Step { get; set; } = UserStep.MainMenu;

    public string? SelectedCategoryId { get; set; }
    public string? SelectedPartId { get; set; }

    public int ParameterIndex { get; set; }

    public Dictionary<string, string> Answers { get; } = new();

    public void Reset()
    {
        Step = UserStep.MainMenu;
        SelectedCategoryId = null;
        SelectedPartId = null;
        ParameterIndex = 0;
        Answers.Clear();
    }
}
